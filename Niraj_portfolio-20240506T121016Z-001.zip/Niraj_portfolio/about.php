<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Me</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="scripts/main.js"></script>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand" href="#">Portfolio</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="projects.php">Projects</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <section class="about">
        <div class="container">
            <h2>About Me</h2>
            <p>I'm a software developer with a passion for building scalable and efficient solutions. I specialize in PHP, JavaScript, and web development.</p>
            <h3>Skills</h3>
            <ul>
                <li>PHP and MySQL</li>
                <li>JavaScript and Node.js</li>
                <li>HTML and CSS</li>
                <li>Responsive Design and Bootstrap</li>
            </ul>
            <h3>Experience</h3>
            <p>I have over 5 years of experience in software development, working on a variety of projects, including e-commerce websites, personal portfolios, and custom web applications.</p>
            <h3>Education</h3>
            <p>I hold a Bachelor's degree in Computer Science from XYZ University, where I gained a solid foundation in software development and computer science principles.</p>
            <h3>Hobbies</h3>
            <p>In my free time, I enjoy hiking, photography, and exploring new technologies. I'm always looking for opportunities to learn and grow.</p>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 Your Name. All rights reserved.</p>
    </footer>
</body>
</html>

<style>


/* About Section Styles */
.about {
    padding: 50px;
    background: #f5f5f5; /* Light gray background */
    color: #333; /* Dark gray text for readability */
    text-align: left; /* Left-aligned text */
}

.about h2 {
    text-align: center;
    font-size: 2.5rem; /* Large heading */
    font-weight: bold;
    color: #005f73; /* Dark teal to match the navbar */
    margin-bottom: 30px; /* Space below the heading */
}

.about h3 {
    font-size: 2rem; /* Slightly smaller than main heading */
    font-weight: bold;
    color: #333; /* Dark gray */
    margin-top: 20px; /* Space above section headings */
    margin-bottom: 10px; /* Space below section headings */
}

.about p {
    font-size: 1.2rem; /* Slightly larger font size for paragraphs */
    line-height: 1.6; /* Increased line-height for readability */
    margin-bottom: 20px; /* Space below paragraphs */
}

.about ul {
    list-style-type: disc; /* Bullet points for lists */
    padding-left: 20px; /* Indentation for lists */
}

.about ul li {
    font-size: 1.2rem; /* Consistent font size for list items */
    line-height: 1.6; /* Consistent line-height */
}
</style>