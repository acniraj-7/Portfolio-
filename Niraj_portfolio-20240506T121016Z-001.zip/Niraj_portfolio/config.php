<?php
// Store your sensitive information as environment variables
putenv('EMAIL_USERNAME= write your mail address'); // Your email address
putenv('EMAIL_PASSWORD=your mail password'); // Your email password or app-specific password
?>

