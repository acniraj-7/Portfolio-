<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Include Bootstrap and custom styles -->
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="scripts/main.js"></script>
    <title>My Portfolio</title>
</head>
<body>
    <!-- Responsive navigation bar -->
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#">IamNiraj</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                <li class="nav-item"><a class="nav-link" href="projects.php">Projects</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
            </ul>

            
        </div>
    </nav>

    <!-- Hero section with a background image and animation -->
    <section class="hero text-center py-5" style="background: url('images/bg-hero.jpg') no-repeat center center; background-size: cover;">
        <div class="container">
            <img src="images/ni.jpg" alt="Profile Photo" class="rounded-circle" style="width: 200px; height: 200px; object-fit: cover; border: 5px solid white; box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); transition: transform 0.3s;">
            <h1 class="mt-4" style="color: white; text-shadow: 2px 2px 8px rgba(0,0,0,0.5);">Welcome to My Portfolio</h1>
            <p style="color:white; text-shadow: 1px 1px 4px rgba(0,0,0,0.5);">I'm a developer who loves creating amazing projects.</p>
        </div>
    </section>

    <!-- Projects section with flex cards and hover effects -->
    <section class="projects py-5">
        <div class="container">
            <h2 class="text-center">My Projects</h2>
            <div class="d-flex justify-content-center flex-wrap">
                <div class="card m-3" style="width: 18rem; transition: transform 0.3s; cursor: pointer;">
                    <img src="images/project-1.jpg" class="card-img-top" alt="Project 1" style="height: 150px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">Project 1</h5>
                        <p class="card-text">A brief description of Project 1. It's a great project that showcases my skills.</p>
                        <a href="#" class="btn btn-primary">Learn More</a>
                    </div>
                </div>


                <div class="card m-3" style="width: 18rem; transition: transform 0.3s; cursor: pointer;">
                    <img src="images/project-1.jpg" class="card-img-top" alt="Project 1" style="height: 150px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">Project 1</h5>
                        <p class="card-text">A brief description of Project 1. It's a great project that showcases my skills.</p>
                        <a href="#" class="btn btn-primary">Learn More</a>
                    </div>
                </div>

                <div class="card m-3" style="width: 18rem; transition: transform 0.3s; cursor: pointer;">
                    <img src="images/project-2.jpg" class="card-img-top" alt="Project 2" style="height: 150px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">Project 2</h5>
                        <p class="card-text">A brief description of Project 2. This project demonstrates my creativity and problem-solving skills.</p>
                        <a href="#" class="btn btn-primary">Learn More</a>
                    </div>
                </div>



                <div class="card m-3" style="width: 18rem; transition: transform 0.3s; cursor: pointer;">
                    <img src="images/project-2.jpg" class="card-img-top" alt="Project 2" style="height: 150px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">Project 2</h5>
                        <p class="card-text">A brief description of Project 2. This project demonstrates my creativity and problem-solving skills.</p>
                        <a href="#" class="btn btn-primary">Learn More</a>
                    </div>
                </div>


                <div class="card m-3" style="width: 18rem; transition: transform 0.3s; cursor: pointer;">
                    <img src="images/project-2.jpg" class="card-img-top" alt="Project 2" style="height: 150px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">Project 2</h5>
                        <p class="card-text">A brief description of Project 3. This project demonstrates my creativity and problem-solving skills.</p>
                        <a href="#" class="btn btn-primary">Learn More</a>
                    </div>
                </div>


            </div>
        </div>
    </section>

    <!-- Footer with social media links -->
    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2024 Your Name. All rights reserved.</p>
        <div>
            <a href="#" class="text-white mx-2"><i class="fab fa-twitter"></i></a>
            <a href="#" class="text-white mx-2"><i class="fab fa-linkedin"></i></a>
            <a href="#" class="text-white mx-2"><i class="fab fa-github"></i></a>
        </div>
    </footer>
</body>
</html>
