<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Projects</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="scripts/main.js"></script>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand" href="#">Portfolio</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="projects.php">Projects</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <section class="projects">
        <div class="container">
            <h2>Projects</h2>
            
            <!-- Project 1 Description -->
            <div class="project">
                <h3>Project 1: Personal Portfolio Website</h3>
                <p>This project involved creating a personal portfolio website to showcase my skills, projects, and experience. The website includes sections for an about me, projects, and contact information.</p>
                <h4>Technologies Used:</h4>
                <p>HTML, CSS, JavaScript, PHP, Bootstrap</p>
                <h4>Challenges Faced:</h4>
                <p>Learning PHP for server-side logic and implementing responsive design with Bootstrap.</p>
                <h4>Outcomes:</h4>
                <p>The website successfully displays my portfolio and has a contact form for visitors to get in touch. It's hosted on a web server and optimized for SEO.</p>
            </div>

            <!-- Project 2 Description -->
            <div class="project">
                <h3>Project 2: E-commerce Website</h3>
                <p>This project involved building an e-commerce website for a small business. The website allows customers to browse products, add items to their cart, and complete purchases securely.</p>
                <h4>Technologies Used:</h4>
                <p>HTML, CSS, JavaScript, PHP, MySQL, Bootstrap</p>
                <h4>Challenges Faced:</h4>
                <p>Implementing secure payment gateways and managing a database with product information and customer orders.</p>
                <h4>Outcomes:</h4>
                <p>The e-commerce website is fully functional and has a user-friendly interface. It provides secure payment options and includes an admin panel for managing products and orders.</p>
            </div>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 Your Name. All rights reserved.</p>
    </footer>
</body>
</html>


<style>
/* Projects Section */
.projects {
    padding: 50px 0;
    background: #f5f5f5; /* Light background for the project section */
    color: #333; /* Dark text for readability */
    display: flex;
    flex-direction: column; /* Allows vertical centering */
    justify-content: center; /* Horizontal centering */
    align-items: center; /* Vertical centering */
    flex-wrap: wrap;
}

.projects h2 {
    text-align: center;
    font-size: 2.5rem; /* Larger, clearer heading */
    font-weight: bold;
    color: #005f73; /* Dark teal for consistency with navbar and footer */
    margin-bottom: 30px;
    width: 100%; /* Ensures the heading takes full width */
}

.project {
    width: calc(50% - 30px); /* Two projects per row with spacing */
    margin: 0 15px; /* Horizontal spacing */
    padding: 20px;
    background: #fff; /* White background for project card */
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s, box-shadow 0.3s;
}

.project:hover {
    transform: translateY(-5px); /* Lift on hover */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1); /* Increase shadow on hover */
}

.project h3 {
    font-size: 1.8rem; /* Large subheading for project titles */
    color: #333; /* Dark gray for text */
    margin-bottom: 10px; /* Space between title and text */
}

.project p {
    font-size: 1.1rem; /* Standard font size for body text */
    line-height: 1.6; /* Increased line-height for better readability */
    margin-bottom: 20px; /* Space between paragraphs */
}

.project h4 {
    font-size: 1.3rem; /* Larger font size for section headings */
    font-weight: bold;
    color: #005f73; /* Dark teal to maintain consistency */
    margin-bottom: 10px;
}

.card img {
    width: 100%; /* Ensure image takes full width */
    height: auto;
    border-radius: 10px; /* Rounded corners for images */
}

.btn {
    background: #005f73; /* Dark teal for buttons */
    color: white;
    transition: background 0.3s; /* Smooth transition for hover effects */
    border-radius: 5px; /* Rounded corners for buttons */
    padding: 10px 20px; /* Padding for button */
}

.btn:hover {
    background: #00394c; /* Darker shade on hover */
}

@media screen and (max-width: 768px) {
    .project {
        width: calc(100% - 30px); /* Full width on smaller screens */
    }
}


</style>