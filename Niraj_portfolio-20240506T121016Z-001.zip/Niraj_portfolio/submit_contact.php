<?php

require 'config.php'; // Load environment variables
// Rest of your code...

require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';
require 'vendor/phpmailer/phpmailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Environment variables for sensitive data
$emailUsername = getenv('EMAIL_USERNAME');
$emailPassword = getenv('EMAIL_PASSWORD');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $message = htmlspecialchars(trim($_POST['message']));

    if (!empty($name) && !empty($email) && !empty($message)) {
        $mail = new PHPMailer(true);

        try {
            // SMTP configuration for Gmail using environment variables
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = $emailUsername; // Your Gmail address from environment variable
            $mail->Password = $emailPassword; // Gmail app-specific password from environment variable
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            // Email content
            $mail->setFrom($emailUsername, 'Niraj'); // Update with your name or business name
            $mail->addAddress('bishwash@ismt.edu.np'); // Replace with your recipient's email
            $mail->Subject = 'Contact Form Submission';
            $mail->Body = "Name: $name\nEmail: $email\n\nMessage:\n$message";

            // Send the email
            $mail->send();
            echo 'Thank you for your message!';
        } catch (Exception $e) {
            echo 'Failed to send the message. Please try again later.';
            error_log("Mailer Error: " . $mail->ErrorInfo); // Log the error for debugging
        }
    } else {
        echo 'All fields are required!';
    }
} else {
    echo 'Invalid request method.';
}
